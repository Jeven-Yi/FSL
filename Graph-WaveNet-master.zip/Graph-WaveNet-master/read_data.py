import numpy as np
# print(np.random.randn(2,2))
import pandas as pd
data=pd.read_csv('F:/dahua/Graph-WaveNet-master/mydata/traffic.csv')
time=data['time']
time_new=[]
for i in time:
    i_list=i.split('/')
    i_list_new=[]
    for i,j in enumerate (i_list):
        if i == 0:
            i_list_new.append(j)
            continue
        if i == 1:
            j_new='0'+j
            i_list_new.append(j_new)
        else:
            j_new = '0' + j
            t_new = j_new.split(':')
            if len(t_new[0])==4:
                j_new = j_new[:3] + '0' + j_new[3:]
            i_list_new.append(j_new)

    i_new='-'.join(i_list_new)
    time_new.append(i_new)

time_new = pd.to_datetime(data['time'],format = '%Y-%m-%d %H:%M:%S')
data.index=time_new
data.drop('time',axis = 1,inplace = True)
H5_data=pd.HDFStore(r'F:\dahua\Graph-WaveNet-master\data'+'/traffic.h5','w')
H5_data['df']=data
H5_data.close()

# data=pd.HDFStore(r'F:\dahua\Graph-WaveNet-master\data'+'/traffic.h5')
# print(data['df'])


